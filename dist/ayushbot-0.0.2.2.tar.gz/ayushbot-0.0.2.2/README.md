ayushbot interfaces mitsuku or kuki with whatsapp and this chatbot allows you to rest while the bot talks to your friends

## Documentation

### One Command You Need

```
ayushbot('receiver')
```
Replace `receiver` with a string or a list containing all the contacts as they appear in Whatsapp
